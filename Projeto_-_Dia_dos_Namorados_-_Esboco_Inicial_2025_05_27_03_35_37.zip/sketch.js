let envelopeX, envelopeY, envelopeWidth, envelopeHeight;
let envelopeSpeed = 2; // velocidade de queda
let envelopeArrived = false;
let envelopeOpen = false;
let falling = true; // está caindo
let showMessage = false;

function setup() {
  createCanvas(400, 400);
  envelopeX = width / 2 - 50;
  envelopeY = -60; // começa fora do visual
  envelopeWidth = 100;
  envelopeHeight = 60;
}

function draw() {
  background(255, 182, 193); // fundo rosa claro

  if (falling) {
    // animação de queda
    envelopeY += envelopeSpeed;
    if (envelopeY >= height / 2 - envelopeHeight / 2) {
      envelopeY = height / 2 - envelopeHeight / 2;
      falling = false; // chegou na posição
    }
  }

  if (falling || !showMessage) {
    // desenha o envelope antes de abrir ou enquanto está caindo
    fill(255);
    rect(envelopeX, envelopeY, envelopeWidth, envelopeHeight);
    drawHeart(envelopeX + envelopeWidth / 2, envelopeY + envelopeHeight / 2, 20);
  }

  if (showMessage) {
    // mostra o cartão de mensagem
    fill(255);
    rect(width / 2 - 150, height / 2 - 100, 300, 200, 20);
    fill(200);
    rect(width / 2 - 150, height / 2 - 100, 300, 200, 20);
    fill(0);
    textSize(14);
    textAlign(CENTER, TOP);
    text("Querido(a),\n\nTe envio este pequeno trecho do meu coração direto de Paris!\n\nCom todo meu amor,\nYasmine", width / 2, height / 2 - 80);
  }

  // botão para fechar/abrir mensagem
  if (showMessage) {
    fill(255, 0, 0);
    ellipse(width - 30, 30, 20, 20);
    fill(255);
    textSize(12);
    textAlign(CENTER, CENTER);
    text("X", width - 30, 30);
  }
}

// função para desenhar o coração
function drawHeart(x, y, size) {
  fill(255, 0, 0);
  noStroke();
  push();
  translate(x, y);
  beginShape();
  vertex(0, -size / 2);
  bezierVertex(-size / 2, -size / 2, -size / 2, 0, 0, size / 4);
  bezierVertex(size / 2, 0, size / 2, -size / 2, 0, -size / 2);
  endShape(CLOSE);
  pop();
}

function mouseClicked() {
  // se clicou no botão fechar/abrir
  if (showMessage) {
    if (
      dist(mouseX, mouseY, width - 30, 30) < 10
    ) {
      showMessage = false; // fecha mensagem
    }
  } else if (
    mouseX > envelopeX &&
    mouseX < envelopeX + envelopeWidth &&
    mouseY > envelopeY &&
    mouseY < envelopeY + envelopeHeight &&
    !falling
  ) {
    // Se clicar no envelope após cair
    showMessage = true; // abre a mensagem
  }
}

// para reiniciar a animação após fechar
function keyPressed() {
  if (key === 'r' || key === 'R') {
    // Pressione 'R' para reiniciar a queda
    envelopeY = -60;
    falling = true;
    showMessage = false;
  }
}